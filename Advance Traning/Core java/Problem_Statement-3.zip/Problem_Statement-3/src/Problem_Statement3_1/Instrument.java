package Problem_Statement3_1;


public abstract class Instrument {
	public abstract void play();
}
